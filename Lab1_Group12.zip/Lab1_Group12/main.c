
#include "mcc_generated_files/mcc.h" //default library 



// ++++++++++++ Helpful Notes ++++++++++++++++


/*
 include or set any library or definition you think you will need
 */

// ====================  prototype functions: ====================


/* There are two ways to generate a PWM signal: 
 *  
   1 . Using the internal PWM module ( enabling and configuring CCP1 module and enabling Timer 2 )  - If you go with this way there is a guide below to enable Timer 2 and CCP1 module
   2 . Handling a GPIO pin and delay functions  - Come p with your own prototype funciton
 *
*/


/*  Enabling and Configuring Timer 2 : Optional
 * 
 *  example: void Timer2_Init(void)  {}     
 *  Configure Timer 2 and start it
    
 USE Timer 2
 * 
 * ---- Set the Registers below:-----------
 * 
 * 1. Set the Basic Configuration Register for Timer 2 
 * 2. Set the Clock Source in relation with system Oscillator frequency 
 * 3. T2PSYNC Not Synchronized; T2MODE Software control; T2CKPOL Rising Edge; T2CKSYNC Not Synchronized; Timer Mode
 * 4. T2RSEL T2CKIPPS pin; Reset Source
 * 5. Set PR2 255; 
 * 6. Set TMR2  Prescale Value to 0 
 * 7. Clearing IF flag.
 * 8. Start Timer2
 * 
 * ----------------------
 */  



/*   Enabling and Configuring CCP1 module : Optional
 * 
 * example: void PWM_Init(void)  {}  
 *  Configure CCP1 module in PWM mode (PWM channel = RC3 by default, Timer selection)
  Registers:
 * 
 * --- Set the Registers below: ---
 * 
 * 1. Set up CCP1 module register in PWM mode and bits alignment
 * 2. Set RH to 0; 
 * 3. Set RL to 0; 
 * 4. Selecting Timer 2 - for PWM in CCP1 module
 * 
 * ---------------
  */ 



/*  Enabling and configuring ADC module:  Mandatory  
 * 
 * example: void ADC_Init(void)  {}   
 *  Configure ADC module  

 ----- Set the Registers below::
 * 1. Set ADC CONTROL REGISTER 1 to 0 
 * 2. Set ADC CONTROL REGISTER 2 to 0 
 * 3. Set ADC THRESHOLD REGISTER to 0
 * 4. Disable ADC auto conversion trigger control register
 * 5. Disable ADACT  
 * 6. Clear ADAOV ACC or ADERR not Overflowed  related register
 * 7. Disable ADC Capacitors
 * 8. Set ADC Precharge time control to 0 
 * 9. Set ADC Clock 
 * 10 Set ADC positive and negative references
 * 11. ADC channel - Analog Input
 * 12. Set ADC result alignment, Enable ADC module, Clock Selection Bit, Disable ADC Continuous Operation, Keep ADC inactive
 
  */ 


// -------  your own prototype function designs :

/* 
 PWM_signal_out() prototype function 
 *
 *- you set 10bits value for the duty cycle being careful with the MSB/LSB alignment 
 *- Set the appropriate Registers in the right sequence
 */



/*
 ADC_conversion_results() prototype function
 * 
 * - set your ADC channel , activate the ADC module , and get the ADC result to a value , then deactivate again the ADC module
 * - Set the appropriate Registers in the right sequence
 */

//++++++++++++++++++++++++++++++++++++++++++++++++++++++




/*
Develop your Application logic below
*/
void Timer2_Init(void)  
{
    T2CLKCONbits.CS = 0x1;
    T2HLT = 0x00;
    T2RST = 0x00;
    PR2   = 0xFF;
    TMR2  = 0x00;
    PIR4bits.TMR2IF = 0;
    T2CONbits.ON = 1;
    
} 

void PWM_Init(void)  
{
    CCP1CONbits.EN  = 1; // ENABLING THE 
    CCP1CONbits.FMT = 0; //RIGHT ALLIGNED FORMAT
    CCP1CONbits.MODE = 0xF; // SETTING THE MODE TO PWM
    CCPR1H = 0x00;   // RH TO 0 
    CCPR1L = 0X00;   //RL TO 0
    CCPTMRS1 = 0X10; // SELECTS TIMER2
    
} 
PWM_signal_out()
{
    CCPR1H  = 0x02;
    CCPR1L  = 0x08;
    
}
//ADC Conversion Results
int ADC_conversion_results()
{
    TRISAbits.TRISA0 = 1; // SETTING PORTA PIN0 TRISTATE REGISTER TO INPUT
    ANSELAbits.ANSA0 = 1; // SETTING PORTA PIN0 AS A ANALOG INPUT
    ADCON0bits.ADON = 1;  // ACTIVATING THE ADC MODULE
    ADCON0bits.GO = 1;    // START CONVERTING
    while(ADCON0bits.ADGO)// WAIT UNTIL THE CONVERSION
    {
    }
    int b = (ADRESH<<8)+(ADRESL); // MAKE THE ADC RESULT IN 10BITS 
    return(b); // RETURN THE RESULT VALUE
     ADCON0bits.GO = 0; // STOP CONVERTING
}

void ADC_Init(void)  
{
    ADCON1 = 0x00; // setting control register 1 to 0
    ADCON2 = 0x00; // setting control register 2 to 0
    ADCON3 = 0x00; // setting control register 3 to 0
    ADSTAT = 0x00; // setting threshold register and not overflowed  to 0
    ADCAP  = 0x00; // disabling ADC capacitors
    ADACT  = 0x00; // disabling Auto conversion trigger control register
    ADPRE  = 0x00; // setting precharge time control to 0 
    ADCLK  = 0x00; // setting ADC clk
    ADREF  = 0x00; // setting ADC positive and negative reference voltages 
    ANSELAbits.ANSA0 = 1; // setting ADC analog channel input to 1
    ADCON0 = 0x84; // setting ADCON0 to the required mode.
    
}

void main(void)
{
    // Initialize PIC device
    SYSTEM_Initialize();

    // Initialize the ADC module
    ADC_Init();
    // Initialize the Timer2 module
    Timer2_Init();
    //Initialize the PWM module
    PWM_Init();
    // **** write your code 
    
    TRISAbits.TRISA4 = 0; //SETTING THE PORTA PIN4 TRISTATE REGISTER TO OUTPUT
    TRISCbits.TRISC3 = 0;
    while (1) // keep your application in a loop
    {
        
        int ADC_Value = ADC_conversion_results(); // GET THE ADC RESULT
        if(ADC_Value < 300) 
            PORTAbits.RA4 = 1; //TURN ON THE LED
        else
            PORTAbits.RA4 = 0; // TURNOFF THE LED
        
        PORTCbits.RC3 = PWM_signal_out(); 
    }
        
}
    

/**
 End of File
*/